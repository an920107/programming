/**
 * Exam 1
 * Name: 游宗穎
 * Student Number: 110502557
 * Course: 2021-CE1001B
 */

#include <bits/stdc++.h>
using namespace std;

string solve(int n) {
    
}

int main() {
    FILE *file = fopen("N.txt", "r");
    int n;
    fscanf(file, "%d", &n);
    fclose(file);
    file = fopen("110502557.txt", "w");
    string res = solve(n);
    res.pop_back();
    fprintf(file, "%s", res.c_str());
    return 0;
}